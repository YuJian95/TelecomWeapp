import en from './en'
import zh_CN from './zh_CN'
import zh_TW from './zh_TW'

export default {
	en,
	zh_CN,
	zh_TW,
}