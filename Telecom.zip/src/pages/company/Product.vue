<template>
  <div>

  </div>
</template>

<script>
export default {
  name: 'Product'
}
</script>

<style scoped>

</style>
